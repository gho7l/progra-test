
import blocks.Block;
import blocks.Brick;
import blocks.End;
import blocks.Grass;
import blocks.Start;
import blocks.Water;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author OliPa639
 */
public class BlockMap {
    private Block[][] map = new Block[30][30];
    private int dim;
    private Point player = new Point(-1,-1);
    private ArrayList<Point> way = new ArrayList<>();
    private ArrayList<Point> shortWay = new ArrayList<>();
    
    public static final int DIAMETER = 20;
    public static final int RECTANGLEWIDTH = 20;
    public static final int RECTANGLEHEIGHT = 10;
    
    public static final int UP = 0;
    public static final int DOWN = 1;
    public static final int LEFT = 2;
    public static final int RIGHT = 3;
    
    public static final int GRASS = 0;
    public static final int WATER = 1;
    public static final int BRICK = 2;
    public static final int START = 3;
    public static final int END = 4;   
        
    public BlockMap() {
        dim  = map.length;
    }
    
    public void drawGrid(Graphics g) {
        g.setColor(Color.BLACK);
        for(int i = 0; i < 30; i++) {
            g.drawLine(i*Block.SQUARESIZE, 0, i*Block.SQUARESIZE, dim*Block.SQUARESIZE);
            g.drawLine(0, i*Block.SQUARESIZE, dim*Block.SQUARESIZE, i*Block.SQUARESIZE);
        }
    }
    
    public int getDim() { return dim; }
    
    public Block getNewBlock(int block) {
        if(block == WATER) return new Water();
        if(block == GRASS) return new Grass();
        if(block == BRICK) return new Brick();
        if(block == START && !hasStart()) return new Start();
        if(block == END) return new End();
        return null;
    }
    
    public boolean hasStart() {
        for(int i = 0; i < dim; i++)
            for(int j = 0; j < dim; j++)
        //for(Block[] b : map)
            //for(Block b : row)        
                if(map[i][j] instanceof Start)
                    return true;
        return false;
    }
    
    public void addBlock(int pI, int pJ, int block) {
        Block newBlock = getNewBlock(block);
        if(map[pI][pJ] == null && newBlock != null)
            map[pI][pJ] = newBlock;
        else 
            Toolkit.getDefaultToolkit().beep();
    }
    
    public void removeBlock(int pI, int pJ) {
        if(map[pI][pJ] != null)
            map[pI][pJ] = null;
    }
    
    public void draw(Graphics g) {
        for(int i = 0; i < dim; i++)
            for(int j = 0; j < dim; j++)
                if(map[i][j] != null) {
                    map[i][j].draw(g, i*Block.SQUARESIZE, j*Block.SQUARESIZE);
                }
        
        if(player.getX() >= 0) {
            g.setColor(Color.RED);
            g.fillOval((int) (player.getX()*Block.SQUARESIZE+Block.SQUARESIZE/4), 
                    (int) (player.getY()*Block.SQUARESIZE+Block.SQUARESIZE/4), 
                    DIAMETER, DIAMETER);
            g.fillRect((int) (player.getX()*Block.SQUARESIZE+Block.SQUARESIZE/4), 
                    (int) (player.getY()*Block.SQUARESIZE+DIAMETER+Block.SQUARESIZE/4),
                    RECTANGLEWIDTH, RECTANGLEHEIGHT);
            
            g.setColor(Color.BLACK);
            g.drawOval((int) (player.getX()*Block.SQUARESIZE+Block.SQUARESIZE/4), 
                    (int) (player.getY()*Block.SQUARESIZE+Block.SQUARESIZE/4),
                    DIAMETER, DIAMETER);
            g.drawRect((int) (player.getX()*Block.SQUARESIZE+Block.SQUARESIZE/4), 
                    (int) (player.getY()*Block.SQUARESIZE+DIAMETER+Block.SQUARESIZE/4),
                    RECTANGLEWIDTH, RECTANGLEHEIGHT);
        }
        
//        showAnyWay(g);
        showShort(g);
        showDistance(g);
    }
    
    public Point getStartBlock() {
        int x = -1;
        int y = -1;
        for(int i = 0; i < dim; i++) 
            for(int j = 0; j < dim; j++)
                if(map[i][j] instanceof Start) {
                    x = i;
                    y = j;
                }
       return new Point(x, y);
    }
    
    public Point getEndBlock() {
        int x = -1;
        int y = -1;
        for(int i = 0; i < dim; i++) 
            for(int j = 0; j < dim; j++)
                if(map[i][j] instanceof End) {
                    x = i;
                    y = j;
                }
       return new Point(x, y);
    }
    
    public void resetPlayer() {
        Point start = getStartBlock();
        if(start.getX() > 0 && start.getY() > 0) {
            player = new Point((int) start.getX(), (int) start.getY());
        }
        //System.out.println(start.getX() +" "+ start.getY());
    }
    
    public void movePlayer(int pMove) {
        if(player.getX() >= 0 && player.getY() >= 0 && player.getX() < dim && player.getY() < dim) {
            int x = (int) player.getX();
            int y = (int) player.getY();
            if(pMove == UP && y >= 0) {
                if(map[x][y-1] != null && map[x][y-1].isWalkable())
                    y -= 1;
            }
            else if(pMove == DOWN && y <= 30) {
                if(map[x][y+1] != null && map[x][y+1].isWalkable())
                    y += 1;
            }
            if(pMove == LEFT && x >= 0) {
                if(map[x-1][y] != null && map[x-1][y].isWalkable())
                    x -= 1;
            }
            if(pMove == RIGHT && x <= 30) {
                if(map[x+1][y] != null && map[x+1][y].isWalkable())
                    x += 1;
            }

            player = new Point(x, y);

            if(map[x][y] instanceof End)
                System.out.println("YOU WON!");
        }
    }
    
    public void saveTxt(String name) throws IOException {
        try(PrintWriter out = new PrintWriter(new FileWriter(name))) {
            for(int i = 0; i < dim; i++)
                for(int j = 0; j < dim; j++)
                    if(map[i][j] != null)
                        out.println(map[i][j].getTypeOfBlock()+":"+i+":"+j);
        }
    }
    
    public void loadTxt(String name) throws FileNotFoundException, IOException {
        try(BufferedReader in = new BufferedReader(new FileReader(name))) {
            String line;
            while((line = in.readLine()) != null) {
                String split[] = line.split(":");
                String block = split[0];
                int x = Integer.valueOf(split[1]);
                int y = Integer.valueOf(split[2]);
                int blockType = -1;
                if(block.equals("Brick"))
                    blockType = BRICK;
                else if(block.equals("Water"))
                    blockType = WATER;
                else if(block.equals("Grass"))
                    blockType = GRASS;
                else if(block.equals("Start"))
                    blockType = START;
                else if(block.equals("End"))
                    blockType = END;
                addBlock(x, y, blockType);
            }
        }
    }
    
    public boolean findWayOut(int col, int row, ArrayList<Point> wayout) {
        boolean result = false;
        if(col >= 0 && row >= 0 && map[col][row] != null)
            if(map[col][row].isWalkable())
                if(map[col][row] instanceof End) {
                    result = true;
                    wayout.add(new Point(col, row));
                }
                else if(!map[col][row].isMarked()) {
                    map[col][row].mark();
                    result = (
                        (col>0 && findWayOut(col-1, row, wayout))
                        || (col<dim-1 && findWayOut(col+1, row, wayout))
                        || (row>0 && findWayOut(col, row-1, wayout))
                        || (row<dim && findWayOut(col, row+1, wayout)));
                }
        if(result) wayout.add(new Point(col, row));
        way = wayout;
        return result;        
    }
    
    public boolean isInGame() {
        return player.getX() >= 0 && player.getY() >= 0 && player.getX() < dim && player.getY() < dim;
    }
    
    public void resetDistances() {
        for(int i = 0; i < dim; i++)
                for(int j = 0; j < dim; j++) 
                    if(map[i][j] != null ) 
                        if(map[i][j].isWalkable())
                            map[i][j].setDistance(-1);
                            
    }
    
    public void setDistances() {
        if(isInGame()) {
            int pX = (int) player.getX();
            int pY = (int) player.getY();
            map[pX][pY].setDistance(0);
            setDistances(pX, pY);
        }        
    }
    
    public void setDistances(int x, int y) {
        int newDistance = map[x][y].getDistance()+1;
        if(map[x+1][y] != null && new Point(x, y) != player)
            if(map[x+1][y].getDistance() > 0 && map[x+1][y].getDistance() > newDistance && map[x+1][y].isWalkable() || map[x+1][y].getDistance() < 0) {
                map[x+1][y].setDistance(newDistance);
                setDistances(x+1, y);
            }
        if(map[x-1][y] != null)
            if(map[x-1][y].getDistance() > 0 && map[x-1][y].getDistance() > newDistance && map[x-1][y].isWalkable() || map[x-1][y].getDistance() < 0 ) {
                map[x-1][y].setDistance(newDistance);
                setDistances(x-1, y);
            }
        if(map[x][y+1] != null)
            if(map[x][y+1].getDistance() > 0 && map[x][y+1].getDistance() > newDistance && map[x][y+1].isWalkable() || map[x][y+1].getDistance() < 0 ) {
                map[x][y+1].setDistance(newDistance);
                setDistances(x, y+1);
            }
        if(map[x][y-1] != null)
            if(map[x][y-1].getDistance() > 0 && map[x][y-1].getDistance() > newDistance && map[x][y-1].isWalkable() || map[x][y-1].getDistance() < 0 ) {
                map[x][y-1].setDistance(newDistance);
                setDistances(x, y-1);
            }
                
    }
    
    public void unmarkAll() {
        for(int i = 0; i < dim; i++)
            for(int j = 0; j < dim; j++)
                if(map[i][j] != null)
                    map[i][j].unmark();
    }
    
    public void showAnyWay(Graphics g) {        
        for(int i = 0; i < dim; i++)
            for(int j = 0; j < dim; j++)
                if(map[i][j] != null) map[i][j].unmark();
        if(isInGame()) {
            unmarkAll();
            findWayOut((int) player.getX(), (int) player.getY(), new ArrayList<Point>());
            for(int i = 0; i < way.size(); i++) {
                g.setColor(Color.ORANGE);
                g.fillOval((int) (way.get(i).getX()*Block.SQUARESIZE+Block.SQUARESIZE*3/8),
                        (int) (way.get(i).getY()*Block.SQUARESIZE+Block.SQUARESIZE*3/8), 
                        Block.SQUARESIZE/4, Block.SQUARESIZE/4);
            }
        }
    }
    
    public void showShort(Graphics g) {        
        for(int i = 0; i < dim; i++)
            for(int j = 0; j < dim; j++)
                if(map[i][j] != null) map[i][j].unmark();
        if(isInGame()) {
            unmarkAll();
            fillShortWay();
            for(int i = 0; i < shortWay.size(); i++) {
                g.setColor(Color.BLUE);
                g.fillOval((int) (shortWay.get(i).getX()*Block.SQUARESIZE+Block.SQUARESIZE*3/8),
                        (int) (shortWay.get(i).getY()*Block.SQUARESIZE+Block.SQUARESIZE*3/8), 
                        Block.SQUARESIZE/4, Block.SQUARESIZE/4);
            }
        }
    }
    
    public void showDistance(Graphics g) {
        resetDistances();
        setDistances();
        if(isInGame())
            for(int i = 0; i < dim; i++)
                for(int j = 0; j < dim; j++) 
                    if(map[i][j] != null ) 
                        if(map[i][j] instanceof Grass) {
                            g.setColor(Color.RED);
                            g.drawString(String.valueOf(map[i][j].getDistance()), 
                                    i*Block.SQUARESIZE+24, j*Block.SQUARESIZE+14);
                        }               
    }
    
    public void fillShortWay() {
        Block nearestEnd = null;
        int x = -1;
        int y = -1;
        for(int i = 0; i < dim; i++)
            for(int j = 0; j < dim; j++)
                if(map[i][j] instanceof End)
                    if(nearestEnd == null || nearestEnd.getDistance() < map[i][j].getDistance()) {
                        nearestEnd = map[i][j];
                        x = i;
                        y = j;
                    }
        if(nearestEnd != null && x != -1 && y != -1) {
            shortWay.add(new Point(x, y));
            fillShortWay(x, y);
        }
    }
    
    public void fillShortWay(int pX, int pY) {
        if(map[pX][pY] != null && map[pX][pY].getDistance() != 0) {
            int x = -1;
            int y = -1;
            int diff = -1;
            //mark
            if(map[pX+1][pY] != null && map[pX+1][pY].isWalkable())
                if(diff < 0 || map[pX+1][pY].getDistance() < diff) {
                    diff = map[pX+1][pY].getDistance();  
                    x = pX+1;
                    y = pY;
                }
            if(map[pX-1][pY] != null && map[pX-1][pY].isWalkable())
                if(diff < 0 || map[pX-1][pY].getDistance() < diff) {
                    diff = map[pX-1][pY].getDistance();  
                    x = pX-1;
                    y = pY;
                }
            if(map[pX][pY+1] != null && map[pX][pY+1].isWalkable())
                if(diff < 0 || map[pX][pY+1].getDistance() < diff) {
                    diff = map[pX][pY+1].getDistance();  
                    x = pX;
                    y = pY+1;
                }
            if(map[pX][pY-1] != null && map[pX][pY-1].isWalkable())
                if(diff < 0 || map[pX][pY-1].getDistance() < diff) {
                    diff = map[pX][pY-1].getDistance();  
                    x = pX;
                    y = pY-1;
                }
            if(map[x][y] != null && x != -1 && y != -1) {
                shortWay.add(new Point(x, y));
                fillShortWay(x, y);
            }
        }
    }
}
