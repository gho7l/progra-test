/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blocks;

import java.awt.Graphics;

/**
 *
 * @author OliPa639
 */
public abstract class Block {
    public static final int SQUARESIZE = 40;
    protected int x, y;
    protected boolean mark = false;
    protected int distance = -1;
    
    public abstract void draw(Graphics g, int x, int y);
    
    public abstract String getTypeOfBlock();
    
    public abstract boolean isWalkable();
    
    public void setDistance(int distance) { this.distance = distance; }
    public int getDistance() { return distance; }    
    public void mark() { mark = true; }    
    public void unmark() { mark = false; }    
    public boolean isMarked() { return mark; }
}
