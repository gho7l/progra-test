/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blocks;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author OliPa639
 */
public class Brick extends Block {

    @Override
    public void draw(Graphics g, int x, int y) {
        g.setColor(Color.GRAY);
        g.fillRect(x, y, SQUARESIZE, SQUARESIZE);
        g.setColor(Color.BLACK);
        g.drawRect(x, y, SQUARESIZE, SQUARESIZE);
        g.drawLine(x, y, x+SQUARESIZE, y+SQUARESIZE);
        g.drawLine(x, y+SQUARESIZE, x+SQUARESIZE, y);
    }

    @Override
    public String getTypeOfBlock() {
        return "Brick";
    }

    @Override
    public boolean isWalkable() {
        return false;
    }
    
}
