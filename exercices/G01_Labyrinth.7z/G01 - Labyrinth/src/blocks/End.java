/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blocks;

import static blocks.Block.SQUARESIZE;
import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author OliPa639
 */
public class End extends Block{
    
    public End() {
        distance = 0;
    }
    
    @Override
    public void draw(Graphics g, int x, int y) {
        g.setColor(Color.GREEN);
        g.fillRect(x, y, SQUARESIZE, SQUARESIZE);
        g.setColor(Color.BLACK);
        g.drawRect(x, y, SQUARESIZE, SQUARESIZE);
        g.drawString("END", x+9, y+14);        
    }
    
    @Override
    public String getTypeOfBlock() {
        return "End";
    }

    @Override
    public boolean isWalkable() {
        return true;
    }
}
