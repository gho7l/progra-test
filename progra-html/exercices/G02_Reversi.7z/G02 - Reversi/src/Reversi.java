import java.awt.Color;
import java.awt.Graphics;
import java.util.Observable;

public class Reversi extends Observable {
    private final int DIM = 8;
    private Integer grid[][];
    private int cellWidth;
    private int player;     //WHITE
    private int adversary;  //BLACK
    
    //private final int EMPTY = 0;
    public final int WHITE = 1;
    public final int BLACK = 2;
    
    private final int PLAYING = 0;
    private final int WAITING = 1;
    
    private final Color PLA_COL = Color.WHITE;
    private final Color ADV_COL = Color.BLACK;
    
    public Reversi() {
        //init();
    }
    
    public void init() {
        grid = new Integer[DIM][DIM];
        grid[3][3] = WHITE;
        grid[4][4] = WHITE;
        grid[3][4] = BLACK;
        grid[4][3] = BLACK;
        player = PLAYING;
        adversary = WAITING;
        updateObserver();
    }
    
    public int getCurrentColor() {
        if(player == PLAYING) return WHITE;
        else return BLACK;
    } 
    
    public int getWhites() {
        int count = 0;
        for(int i = 0; i < DIM; i++)
            for(int j = 0; j < DIM; j++)
                if(grid[i][j] != null)
                    if(grid[i][j] == WHITE)
                        count += 1;
        return count;
    }
    
    public int getBlacks() {
        int count = 0;
        for(int i = 0; i < DIM; i++)
            for(int j = 0; j < DIM; j++)
                if(grid[i][j] != null)
                    if(grid[i][j] == BLACK)
                        count += 1;
        return count;
    }
    
    public void changePlayer() {
        if(player == PLAYING) {
            adversary = PLAYING;
            player = WAITING;
        }
        else {
            player = PLAYING;
            adversary = WAITING;
        }
        updateObserver();
    }
    
    public void draw(Graphics g, int side) {
        if(player == PLAYING) g.setColor(PLA_COL);
        else if(adversary == PLAYING) g.setColor(ADV_COL);
        
        cellWidth = side/DIM;
        for(int i = 1; i < DIM; i++) {
            g.drawLine(i*cellWidth, 0, i*cellWidth, side);
            g.drawLine(0, i*cellWidth, side, i*cellWidth);
        }
        drawPieces(g, cellWidth);
    }
    
    public void drawPieces(Graphics g, int cellWidth) {
        for(int i = 0; i < DIM; i++)
            for(int j = 0; j < DIM; j++) {
                if(grid[i][j] != null) {
                    if(grid[i][j] == WHITE)
                        g.setColor(Color.WHITE);
                    else if(grid[i][j] == BLACK)
                        g.setColor(Color.BLACK);
                    else g.setColor(Color.RED);
                    g.fillOval(i*cellWidth + cellWidth/10, j*cellWidth + cellWidth/10,
                            cellWidth-cellWidth/5, cellWidth-cellWidth/5);
                }
            }
    }
    
    public boolean placePiece(int x, int y) {
        int col = x/cellWidth;
        int row = y/cellWidth;
        boolean valid = validMove(col, row);
        if(valid) {
            swapPieces(col, row);
            changePlayer();
        }
        return valid;
    }
    
    public boolean validMove(int col, int row) {
        boolean valid = false;
        if(grid[col][row] == null) {
            if(player == PLAYING)
                grid[col][row] = WHITE;
            else grid[col][row] = BLACK;
            valid = checkAbove(col, row) || checkBelow(col, row) || checkDiagBD(col, row)
                    || checkDiagBG(col, row) || checkDiagHD(col, row)
                    || checkDiagHG(col, row) || checkLeft(col, row)
                    || checkRight(col, row);
            grid[col][row] = null;
        }
        return valid;
    }
    
    public void swapPieces(int col, int row) {
        int color;
        if(player == PLAYING) color = WHITE;
        else color = BLACK;
        grid[col][row] = color;
        if(checkAbove(col, row)) {
            int row2 = row-1;
            while(grid[col][row2] != color) {
                grid[col][row2] = color;
                row2 -= 1;
            }
        }
        if(checkBelow(col, row)) {
            int row2 = row+1;
            while(grid[col][row2] != color) {
                grid[col][row2] = color;
                row2 += 1;
            }
        }
        if(checkLeft(col, row)) {
            int col2 = col-1;
            while(grid[col2][row] != color) {
                grid[col2][row] = color;
                col2 -= 1;
            }
        }
        if(checkRight(col, row)) {
            int col2 = col+1;
            while(grid[col2][row] != color) {
                grid[col2][row] = color;
                col2 += 1;
            }
        }
        if(checkDiagBD(col, row)) {
            int col2 = col-1;
            int row2 = row-1;
            while(grid[col2][row2] != color) {
                grid[col2][row2] = color;
                col2 -= 1;
                row2 -= 1;
            }
        }
        if(checkDiagBG(col, row)) {
            int col2 = col+1;
            int row2 = row-1;
            while(grid[col2][row2] != color) {
                grid[col2][row2] = color;
                col2 += 1;
                row2 -= 1;
            }
        }
        if(checkDiagHD(col, row)) {
            int col2 = col-1;
            int row2 = row+1;
            while(grid[col2][row2] != color) {
                grid[col2][row2] = color;
                col2 -= 1;
                row2 += 1;
            }
        }
        if(checkDiagHG(col, row)) {
            int col2 = col+1;
            int row2 = row+1;
            while(grid[col2][row2] != color) {
                grid[col2][row2] = color;
                col2 += 1;
                row2 += 1;
            }
        }
    }
    
    public boolean checkLeft(int col, int row) {
        boolean check = false;
        int first = grid[col][row];
        col -= 1;
        if(col >= 0 && grid[col][row] != null && grid[col][row] != first) {
            col -= 1;
            while(col >= 0 && grid[col][row] != null && check == false) {
                if(grid[col][row] == first)
                    check = true;
                col -= 1;
            }
        }
        return check;
    }
    
    public boolean checkRight(int col, int row) {
        boolean check = false;
        int first = grid[col][row];
        col += 1;
        if(col < DIM && grid[col][row] != null && grid[col][row] != first) {
            col += 1;
            while(col < DIM && grid[col][row] != null && check == false) {
                if(grid[col][row] == first)
                    check = true;
                col += 1;
            }
        }
        return check;
    }
    
    public boolean checkAbove(int col, int row) {
        boolean check = false;
        int first = grid[col][row];
        row -= 1;
        if(row >= 0 && grid[col][row] != null && grid[col][row] != first) {
            row -= 1;
            while(row >= 0 && grid[col][row] != null && check == false) {
                if(grid[col][row] == first)
                    check = true;
                row -= 1;
            }
        }
        return check;
    }
    
    public boolean checkBelow(int col, int row) {
        boolean check = false;
        int first = grid[col][row];
        row += 1;
        if(row < DIM && grid[col][row] != null && grid[col][row] != first) {
            row += 1;
            while(row < DIM && grid[col][row] != null && check == false) {
                if(grid[col][row] == first)
                    check = true;
                row += 1;
            }
        }
        return check;
    }
    
    public boolean checkDiagHG(int col, int row) {
        boolean check = false;
        int first = grid[col][row];
        col += 1;
        row += 1;
        if(col < DIM && row < DIM && grid[col][row] != null && grid[col][row] != first) {
            col += 1;
            row += 1;
            while(col < DIM && row < DIM && grid[col][row] != null && check == false) {
                if(grid[col][row] == first)
                    check = true;
                col += 1;
                row += 1;
            }
        }
        return check;
    }
    
    public boolean checkDiagHD(int col, int row) {
        boolean check = false;
        int first = grid[col][row];
        col -= 1;
        row += 1;
        if(col >= 0 && row < DIM && grid[col][row] != null && grid[col][row] != first) {
            col -= 1;
            row += 1;
            while(col >= 0 && row < DIM && grid[col][row] != null && check == false) {
                if(grid[col][row] == first)
                    check = true;
                col -= 1;
                row += 1;
            }
        }
        return check;
    }
    
    public boolean checkDiagBG(int col, int row) {
        boolean check = false;
        int first = grid[col][row];
        col += 1;
        row -= 1;
        if(col < DIM && row >= 0 && grid[col][row] != null && grid[col][row] != first) {
            col += 1;
            row -= 1;
            while(col < DIM && row >= 0 && grid[col][row] != null && check == false) {
                if(grid[col][row] == first)
                    check = true;
                col += 1;
                row -= 1;
            }
        }
        return check;
    }
    
    public boolean checkDiagBD(int col, int row) {
        boolean check = false;
        int first = grid[col][row];
        col -= 1;
        row -= 1;
        if(col >= 0 && row >= 0 && grid[col][row] != null && grid[col][row] != first) {
            col -= 1;
            row -= 1;
            while(col >= 0 && row >= 0 && grid[col][row] != null && check == false) {
                if(grid[col][row] == first)
                    check = true;
                col -= 1;
                row -= 1;
            }
        }
        return check;
    }
    
    public void updateObserver() {
        setChanged();
        notifyObservers();
    }
}
